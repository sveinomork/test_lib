def main() -> None:
    print("Hello from test-lib!")
